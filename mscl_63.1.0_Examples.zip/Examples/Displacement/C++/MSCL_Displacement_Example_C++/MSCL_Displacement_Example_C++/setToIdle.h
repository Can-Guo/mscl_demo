#pragma once

#include "mscl/mscl.h"

static void setToIdle(mscl::DisplacementNode& node)
{
    node.setToIdle();
}