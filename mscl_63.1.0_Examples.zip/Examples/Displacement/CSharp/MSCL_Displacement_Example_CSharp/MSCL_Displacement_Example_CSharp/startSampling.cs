﻿using System;

namespace MSCL_Displacement_Example_CSharp
{
    class Example3
    {
        public static void startSampling(mscl.DisplacementNode node)
        {
            node.resume();
        }
    }
}